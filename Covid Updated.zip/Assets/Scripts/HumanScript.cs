﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HumanScript : MonoBehaviour
{
    public int currentrate;
    public GameObject Human;
    public float speed;
    private float waitTime;
    public float startWaitTime;
    public float classTime;
    public bool infection;
    private SpriteRenderer rend;
    private int humantype;

    public Transform[] moveSpots;
    private int randomSpot;
    private int randomDesk;
    private int queuespot;

    void Start(){

        randomSpot = Random.Range(0, moveSpots.Length);
        randomDesk = Random.Range(6,9);
        humantype = Random.Range(0, 3);
        queuespot = 2;

        currentrate = 174;
        infection = false;

        if(humantype == 0){
            rend = GetComponent<SpriteRenderer>();
            rend.material.color = Color.white;            
        }
        if(humantype == 1){
            rend = GetComponent<SpriteRenderer>();
            rend.material.color = Color.blue;            
        }
        if(humantype == 2){
            rend = GetComponent<SpriteRenderer>();
            rend.material.color = Color.green;            
        }
    }

    public void OnTriggerEnter2D(Collider2D col){
            HumanScript hscript = col.gameObject.GetComponent<HumanScript>();
            if (col.gameObject != Human){
                GetComponent<BoxCollider2D>().isTrigger = false;
                Update();
            }
            if (col.gameObject == Human){
                if (hscript.infection == true){
                    int x = Random.Range(0, 1000);
                    if (x <=currentrate && x >= 0){
                        infection = true;
                        rend = GetComponent<SpriteRenderer>();
                        rend.material.color = Color.red;
                    }
                }
            }    
    }

    void OnMouseDown(){
            if (infection == true){
                infection = false;
                rend = GetComponent<SpriteRenderer>();
                rend.material.color = Color.white;
            }
            else {
                infection = true;
                rend = GetComponent<SpriteRenderer>();
                rend.material.color = Color.red;
            }          
    }

    public void RateChange (int rate){
        currentrate = rate;
    }

    void Update(){
// 0: Drifter - Walks around aimlessly then leaves
        if (humantype == 0){
            transform.position = Vector2.MoveTowards(transform.position, moveSpots[randomSpot].position, speed * Time.deltaTime);

            if(Vector2.Distance(transform.position, moveSpots[randomSpot].position) < 0.2f){
                if (waitTime <= 0){
                randomSpot = Random.Range(0, moveSpots.Length);
                waitTime = startWaitTime;
                }
            else if(Vector2.Distance(transform.position, moveSpots[1].position) < 0.2f){
                Destroy(Human);
                }
            else{
                waitTime  -= Time.deltaTime;
                }
            }
        }

// 1: Student - Enter a desk position, sits down for a long period, then leaves.
        if (humantype == 1){
            transform.position = Vector2.MoveTowards(transform.position, moveSpots[randomDesk].position, speed * Time.deltaTime);

            if(Vector2.Distance(transform.position, moveSpots[randomDesk].position) < 0.2f){
                if (waitTime <= 0){
                    waitTime = classTime;
                    randomDesk = 1;
                }
            }
            else if(Vector2.Distance(transform.position, moveSpots[1].position) < 0.2f){
                Destroy(Human);
                }
            else{
                waitTime  -= Time.deltaTime;
                }
            }


// 2: Customer - Enters a line, follows the line, then leaves.
        if (humantype == 2){
            transform.position = Vector2.MoveTowards(transform.position, moveSpots[queuespot].position, speed * Time.deltaTime);
            
            if(queuespot == 5){
                if (waitTime <= 0){
                queuespot = 1;
                waitTime = startWaitTime;
                }
            }
            if(Vector2.Distance(transform.position, moveSpots[queuespot].position) < 0.2f){
                if (waitTime <= 0){
                queuespot ++;
                waitTime = startWaitTime;
                }
            else if(Vector2.Distance(transform.position, moveSpots[1].position) < 0.2f){
                Destroy(Human);
                }
            else{
                waitTime  -= Time.deltaTime;
                }
            }
        }




    }
}
